﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.Sqlite;
using System.IO;

namespace ksiazka
{
    public static class DataAcces
    {
        public static void CreateDatabase()
        {
            string dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ksiazka.db");

            if (!File.Exists(dbPath))
            {
                using (var db = new SqliteConnection($"Filename={dbPath}"))
                {
                    db.Open();
                    var createTable = new SqliteCommand();
                    createTable.Connection = db;
                    createTable.CommandText ="CREATE TABLE IF NOT EXISTS PersonTable (Id INTEGER PRIMARY KEY AUTOINCREMENT, Surname TEXT, Name TEXT, Phone TEXT, Email TEXT)";
                    createTable.ExecuteNonQuery();
                }
            }
        }
        public static void NewData()
        {
            string dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ksiazka.db");

            using (var db = new SqliteConnection($"Filename={dbPath}"))
            {
                db.Open();
                var deletetData = new SqliteCommand();
                deletetData.Connection = db;
                deletetData.CommandText = "DELETE FROM PersonTable";
                deletetData.ExecuteNonQuery();
            }
        }

        public static List<Person> GetData()
        {
            List<Person> persons = new List<Person>();

            string dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ksiazka.db");

            using (var db = new SqliteConnection($"Filename={dbPath}"))
            {
                db.Open();
                var select = new SqliteCommand();
                select.Connection = db;
                select.CommandText = "SELECT * FROM PersonTable";

                using (SqliteDataReader reader = select.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Person person = new Person();
                        person.Id = reader.GetInt32(0);
                        person.Surname = reader.GetString(1);
                        person.Name = reader.GetString(2);
                        person.Phone = reader.GetString(3);
                        person.Email = reader.GetString(4);

                        persons.Add(person);
                    }
                }
            }
            return persons;
        }
        
        public static void InsertData(Person person)
        {
            string dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ksiazka.db");

            using (var db = new SqliteConnection($"Filename={dbPath}"))
            {
                db.Open();
                var InsertData = new SqliteCommand();
                InsertData.Connection = db;
                InsertData.CommandText = "INSERT INTO PersonTable VALUES(NULL, @Surname, @Name, @Phone, @Email)";
                InsertData.Parameters.AddWithValue("@Surname", person.Surname);
                InsertData.Parameters.AddWithValue("@Name", person.Name);
                InsertData.Parameters.AddWithValue("@Phone", person.Phone);
                InsertData.Parameters.AddWithValue("@Email", person.Email);
                InsertData.ExecuteNonQuery();
            }
        }

        
        public static void DeleteData(Person person)
        {
            string dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ksiazka.db");

            using (var db = new SqliteConnection($"Filename={dbPath}"))
            {
                db.Open();
                var InsertData = new SqliteCommand();
                InsertData.Connection = db;
                InsertData.CommandText = "DELETE FROM PersonTable WHERE Id = @id";
                InsertData.Parameters.AddWithValue("@id", person.Id);
                InsertData.ExecuteNonQuery();
            }
        }

        
        public static void EditData(Person person)
        {
            string dbPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "ksiazka.db");

            using (var db = new SqliteConnection($"Filename={dbPath}"))
            {
                db.Open();
                var EditData = new SqliteCommand();
                EditData.Connection = db;
                EditData.CommandText = "UPDATE PersonTable SET Surname=@Surname, Name=@Name, Phone=@Phone, Email=@Email WHERE Id = @id";
                EditData.Parameters.AddWithValue("@id", person.Id);
                EditData.Parameters.AddWithValue("@Surname", person.Surname);
                EditData.Parameters.AddWithValue("@Name", person.Name);
                EditData.Parameters.AddWithValue("@Phone", person.Phone);
                EditData.Parameters.AddWithValue("@Email", person.Email);
                EditData.ExecuteNonQuery();
            }
        }
    }
}
