﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ksiazka
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private int pageNumber = 1;
        public MainWindow()
        {
            InitializeComponent();
            DataAcces.CreateDatabase();
            UpdateList();
        }
        private void UpdateList()
        {
            string text = txtSearch.Text;
            List<Person> personsAll = DataAcces.GetData();
            List<Person> persons = new List<Person>();
            foreach(Person e in personsAll)
            {
                if(e.Surname.Contains(text) || e.Name.Contains(text) || e.Phone.Contains(text) || e.Email.Contains(text))
                {
                    persons.Add(e);
                }
            }
            float pages = (float)Math.Ceiling((float)persons.Count / 10);
            personsListView.ItemsSource = persons.Skip((pageNumber - 1)*10).Take(10);
            progressBar.Maximum = pages;
            progressBar.Value = pageNumber;

            if (pageNumber == 1)
            {
                btnPrevious.IsEnabled = false;
            }
            else
            {
                btnPrevious.IsEnabled = true;
            }

            if (pageNumber < pages)
            {
                btnNext.IsEnabled = true;
            }
            else
            {
                btnNext.IsEnabled = false;
            }
        }
        private void New_Click(object sender, RoutedEventArgs e)
        {
            DataAcces.NewData();
            UpdateList();
        }
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            AddEditWindow window = new AddEditWindow();
            window.ShowDialog();
            UpdateList();
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            Console.Beep();
            if(personsListView.SelectedItem != null)
            {
                Person person = personsListView.SelectedItem as Person;
                AddEditWindow window = new AddEditWindow(person);
                window.ShowDialog();
                UpdateList();
            }
            else
            {
                MessageBox.Show("Wybierz index", "Błąd", MessageBoxButton.OK);
            }
        }
        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            Console.Beep();
            if (personsListView.SelectedItem != null)
            {
                Person person = personsListView.SelectedItem as Person;
                DataAcces.DeleteData(person);
                UpdateList();
            }
            else
            {
                MessageBox.Show("Wybierz index", "Błąd", MessageBoxButton.OK);
            }
        }

        private void Previous_Click(object sender, RoutedEventArgs e)
        {
            if(pageNumber > 1)
            {
                pageNumber--;
            }
            UpdateList();
        }

        private void Next_Click(object sender, RoutedEventArgs e)
        {
            pageNumber++;
            UpdateList();
            Console.Beep();
        }

        private void txtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateList();
            Console.Beep();
        }
    }
}
