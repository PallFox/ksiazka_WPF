﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ksiazka
{
    /// <summary>
    /// Logika interakcji dla klasy AddEditWindow.xaml
    /// </summary>
    public partial class AddEditWindow : Window
    {
        bool editMode = false;
        Person person = new Person();
        public AddEditWindow()
        {
            InitializeComponent();
        }
        public AddEditWindow(Person person)
        {
            editMode = true;

            InitializeComponent();

            this.person = person;
            Title = "Edit Window";
            titleLabel.Content = "Edit Person";
            btnConfirm.Content = "Edit";
            txtSurname.Text = person.Surname;
            txtName.Text = person.Name;
            txtPhone.Text = person.Phone;
            txtEmail.Text = person.Email;
        }

        private void Confirm_Click(object sender, RoutedEventArgs e)
        {
            if(Regex.IsMatch(txtSurname.Text, "^[A-ZĄĆĘŁŃÓŚŹŻ][a-ząćęłńóśźż]{1,30}$") && Regex.IsMatch(txtName.Text, "^[A-ZĄĆĘŁŃÓŚŹŻ][a-ząćęłńóśźż]{1,30}$") && Regex.IsMatch(txtPhone.Text, @"^\d{3}-\d{3}-\d{3}$") && Regex.IsMatch(txtEmail.Text, @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"))
            {
                person.Surname = txtSurname.Text;
                person.Name = txtName.Text;
                person.Phone = txtPhone.Text;
                person.Email = txtEmail.Text;

                if (editMode)
                {
                    DataAcces.EditData(person);
                    Close();
                }
                else
                {
                    DataAcces.InsertData(person);
                    Close();
                }
            }
            else
            {
                MessageBox.Show("Niepoprawne dane", "Błąd", MessageBoxButton.OK);
            }
        }
    }
}
