﻿using System;
using System.Collections.Generic;
using System.IO.Packaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ksiazka
{
    public class Person
    {
        public int Id { get; set; }
        public string Surname { get; set; }
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public Person() { }
        public Person(string suraname, string name, string phone, string email)
        {
            Surname = suraname;
            Name = name;
            Phone = phone;
            Email = email;
        }
    }
}
